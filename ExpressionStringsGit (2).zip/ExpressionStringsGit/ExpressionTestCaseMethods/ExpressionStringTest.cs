﻿namespace ExpressionString
{
    [TestClass]
    public sealed class ExpressionstringTest
    {
        [TestMethod]
        public void Test_SimpleAddition()
        {
            string expression = "3 + 5";
            string expected = "8";

            string actual = EvaluateExpression.Evaluate(expression);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_TestWithParanthesis()
        {
            string expression = "3 + (2 * 4) - 5 / (1 + 1)";
            string expected = "8.5";

            string actual = EvaluateExpression.Evaluate(expression);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_TestWithMultidigitNumber()
        {
            string expression = "333+600";
            string expected = "933";

            string actual = EvaluateExpression.Evaluate(expression);

            Assert.AreEqual(expected, actual);
        }
    }
}
