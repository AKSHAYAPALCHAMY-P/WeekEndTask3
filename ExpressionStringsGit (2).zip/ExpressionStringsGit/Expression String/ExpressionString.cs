﻿namespace ExpressionString
{
    public class EvaluateExpression
    {
        public static string Evaluate(string expression)
        {
            Stack<double> dOperands = new Stack<double>();
            Stack<char> chOperators = new Stack<char>();

            for (int i = 0; i < expression.Length; i++)
            {
                char currentChar = expression[i];

                if (currentChar == ' ')
                    continue;

                if (currentChar >= '0' && currentChar <= '9')
                {
                    double val = 0;
                    while (i < expression.Length && expression[i] >= '0' && expression[i] <= '9')
                    {
                        val = val * 10 + (expression[i] - '0');
                        i++;
                    }
                    i--; 
                    dOperands.Push(val);
                }
                else if (currentChar == '+' || currentChar == '-' || currentChar == '*' || currentChar == '/')
                {
                    while (chOperators.Count > 0 && chOperators.Peek() != '(' &&
                           GetPrecedence(chOperators.Peek()) >= GetPrecedence(currentChar))
                    {
                        char chOperator = chOperators.Pop();
                        double nSecond = dOperands.Pop();
                        double nFirst = dOperands.Pop();
                        dOperands.Push(ApplyOperation(chOperator, nFirst, nSecond));
                    }
                    chOperators.Push(currentChar);
                }
                else if (currentChar == '(')
                {
                    chOperators.Push(currentChar);
                }
                else if (currentChar == ')')
                {
                    while (chOperators.Count > 0 && chOperators.Peek() != '(')
                    {
                        char chOperator = chOperators.Pop();
                        double nSecond = dOperands.Pop();
                        double nFirst = dOperands.Pop();
                        dOperands.Push(ApplyOperation(chOperator, nFirst, nSecond));
                    }
                    if (chOperators.Count > 0 && chOperators.Peek() == '(')
                        chOperators.Pop();
                }
            }

            while (chOperators.Count > 0)
            {
                char chOperator = chOperators.Pop();
                double nSecond = dOperands.Pop();
                double nFirst = dOperands.Pop();
                dOperands.Push(ApplyOperation(chOperator, nFirst, nSecond));
            }

            return dOperands.Pop().ToString();
        }

        private static int GetPrecedence(char chOperator)
        {
            if (chOperator == '+' || chOperator == '-') return 1;
            if (chOperator == '*' || chOperator == '/') return 2;
            return 0;
        }

        public static double ApplyOperation(char chOperator, double nFirst, double nSecond)
        {
            switch (chOperator)
            {
                case '+': return nFirst + nSecond;
                case '-': return nFirst - nSecond;
                case '*': return nFirst * nSecond;
                case '/': return nFirst / nSecond;
                default: return 0;
            }
        }
    }
}
